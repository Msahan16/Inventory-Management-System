/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.MReport;

/**
 *
 * @author moham
 */
public class CReport {
        public void Report()
    {
        MReport stdrp = new MReport();
        stdrp.Report();
        
    }
           public void Report1()
    {
        MReport stdrp = new MReport();
        stdrp.Report();
        
    }
           public void Report2()
    {
        MReport stdrp = new MReport();
        stdrp.Report();
        
    }
                  public void Report3()
    {
        MReport stdrp = new MReport();
        stdrp.Report();
        
    }
                         public void Report4()
    {
        MReport stdrp = new MReport();
        stdrp.Report();
        
    }
}
